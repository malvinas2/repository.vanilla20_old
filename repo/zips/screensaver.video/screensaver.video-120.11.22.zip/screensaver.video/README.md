__NOTICE__

__I did some slight modifications to get this addon running in Kodi 19/20, but I do not maintain it actively. If you are interested in taking it over then please contact me via the Issues section.__

All credits go to He-who-must-not-be-named aka Robwebset ;-)


![VideoScreensaver](icon.png)

VideoScreensaver is a screensaver that will play a video file when the screensaver starts. It will support playing either a user specified video file, or one of the following pre-defined video files detailed on the Wiki.

[Add-on:VideoScreensaver](https://github.com/malvinas2/screensaver.video/wiki)
